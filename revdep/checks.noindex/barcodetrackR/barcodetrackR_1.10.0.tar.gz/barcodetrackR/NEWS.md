# barcodetrackR 0.99.0 (2021-02-22)
+ Starting move to bioconductor
+ Moving larger extdata to barcodetrackRData github
