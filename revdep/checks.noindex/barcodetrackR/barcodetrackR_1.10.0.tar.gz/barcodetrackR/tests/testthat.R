library(testthat)
library(barcodetrackR)

test_check("barcodetrackR")
