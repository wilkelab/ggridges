library(testthat)
library(forestecology)

test_check("forestecology")
