library(testthat)
library(datplot)

test_check("datplot")
