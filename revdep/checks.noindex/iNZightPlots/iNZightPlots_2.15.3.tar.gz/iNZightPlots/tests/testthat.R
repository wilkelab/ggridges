library(testthat)
library(iNZightPlots)

test_check("iNZightPlots")
