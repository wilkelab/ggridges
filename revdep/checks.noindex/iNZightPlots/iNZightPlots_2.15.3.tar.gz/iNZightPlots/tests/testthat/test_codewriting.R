context("Plot code writing")

data(iris)
test_that("Basic plot returns valid code", {
    # p <- iNZightPlot(Sepal.Width, data = iris)
    # expect_equal(
    #     attr(p, "code"),
    #      "iNZightPlot(Sepal.Width, data = iris)"
    # )
})
