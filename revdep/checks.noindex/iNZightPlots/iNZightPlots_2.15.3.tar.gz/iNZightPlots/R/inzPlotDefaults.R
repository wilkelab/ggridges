inzPlotDefaults <- function() {
    # Houses all of the default settings for plotting. Alternatively,
    # could edit them (i.e., points to a list in global environment)
    inzpar()
}
