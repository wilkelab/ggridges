resetPlot <- function()
    grid.newpage()
