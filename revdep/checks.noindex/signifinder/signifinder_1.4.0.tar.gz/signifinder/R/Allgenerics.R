
setGeneric(".getMatrix", function(userdata, ...) standardGeneric(".getMatrix"))

setGeneric(".returnAsInput",
    function(userdata, result, ...) standardGeneric(".returnAsInput"))
