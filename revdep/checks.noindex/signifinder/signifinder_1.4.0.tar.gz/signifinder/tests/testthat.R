library(testthat)
library(signifinder)

test_check("signifinder")
