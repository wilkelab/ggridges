.onLoad <- function (libname, pkgname)
{
    
    utils::globalVariables ("model.matrix")
    utils::globalVariables ("t.test")
    utils::globalVariables ("p.adjust")
    utils::globalVariables ("aov")
    utils::globalVariables ("as.formula")
    utils::globalVariables ("factors.x")
    utils::globalVariables ("factors.y")
    utils::globalVariables ("slot")
    utils::globalVariables ("GS")
    utils::globalVariables ("na.omit")
    utils::globalVariables ("segmenty")
    utils::globalVariables ("segmenty2")
    utils::globalVariables ("value")
    utils::globalVariables ("variable")
    utils::globalVariables (".SD")    
    invisible ()

}