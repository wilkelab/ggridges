#' In-Built Gene Sets for Escape  
#' 
#' A list of gene sets derived from PMID: 29961579 relating to tumor immunity.
#' @docType data
#' @name escape.gene.sets
#' 
NULL
