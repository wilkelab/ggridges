library(testthat)
library(GeneTonic)

test_check("GeneTonic")
