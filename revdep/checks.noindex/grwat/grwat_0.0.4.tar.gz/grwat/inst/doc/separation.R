## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, warning=F, message=F----------------------------------------------
library(grwat)
data(spas) # example Spas-Zagorye data is included with grwat package
head(spas)

## ----echo=F, out.width='100%'-------------------------------------------------
knitr::include_graphics('regions.jpg')

## -----------------------------------------------------------------------------
params = gr_get_params(reg = 'south')
head(params)

params = gr_get_params(reg = 2)
head(params)

## -----------------------------------------------------------------------------
gr_help_params()

## -----------------------------------------------------------------------------
params$sprise = 12
params$gratio = 500

## -----------------------------------------------------------------------------
# separate
sep = gr_separate(spas, params)
head(sep)

## -----------------------------------------------------------------------------
# One year
gr_plot_sep(sep, 1978) 

# Two years
gr_plot_sep(sep, c(1978, 2014)) 

# Four years in a matrix layout
gr_plot_sep(sep, 1988:1991, layout = matrix(1:4, nrow = 2, byrow = TRUE)) 

## -----------------------------------------------------------------------------
# Debug mode gives access to additional information
sep_debug = gr_separate(spas, 
                        params = gr_get_params(reg = 'center'), 
                        debug = TRUE)

# a vector of years with jittered params
jit = attributes(sep_debug)$jittered
print(jit)

# actual params used for each year
parlist = attributes(sep_debug)$params
partab = do.call(dplyr::bind_rows, parlist) # View as table
head(partab)

## -----------------------------------------------------------------------------
# extract and tweak parameters for selected year
p = parlist[['2014']]
p$grad1 = 1
p$grad2 = 2.5

# use tweaked parameters for all years
sep_debug = gr_separate(spas, params = p, debug = TRUE)

# Visualize
gr_plot_sep(sep_debug, c(1978, 2014)) 

## -----------------------------------------------------------------------------
# actual params used for each year
parlist = attributes(sep_debug)$params

# tweak parameters for selected year
parlist[['2014']]$grad1 = 3
parlist[['2014']]$grad2 = 6

# set the sprecdays parameter for multiple years
parlist = gr_set_param(parlist, sprecdays, 
                       years = c(1978, 1999:2015), 
                       value = 15)

# set the spcomp parameter for all years
parlist = gr_set_param(parlist, spcomp, value = 2.5)

# use the list of parameters for separation
sep_debug = gr_separate(spas, params = parlist, debug = TRUE)

# Visualize
gr_plot_sep(sep_debug, c(1978, 2014))

