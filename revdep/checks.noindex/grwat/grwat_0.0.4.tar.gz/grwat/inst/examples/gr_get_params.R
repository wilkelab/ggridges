library(grwat)

params = gr_get_params(reg = 'center')

print(params)
