# knitr::write_bib(c(
#   .packages(), 'ggplot2'
# ), './vignettes/packages.bib')