library(testthat)
suppressPackageStartupMessages(library(grwat))

test_check("grwat")
