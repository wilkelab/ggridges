#' @useDynLib HistDAWass
#' @importFrom Rcpp evalCpp
NULL
