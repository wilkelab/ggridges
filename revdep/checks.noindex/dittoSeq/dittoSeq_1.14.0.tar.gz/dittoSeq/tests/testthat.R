library(testthat)
test_check("dittoSeq")
