library(testthat)
library(rsimsum)

test_check("rsimsum")
