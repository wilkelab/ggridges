#' @rdname defunct
#' @export
 
mm <- function(...) { # formula, data=parent.frame(), fun=mean, drop=TRUE, ... ) {
  .Defunct(msg = "mm() is no longer supported.")
}
