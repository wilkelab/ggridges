
#' @rdname defunct
#' @export
deltaMethod <- function(...) {
  .Defunct("deltaMethod", package="deltaMethod", 
           msg = "deltaMethod.data.frame is now in the deltaMethod package.")
}
