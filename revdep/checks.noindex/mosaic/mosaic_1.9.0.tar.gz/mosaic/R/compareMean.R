#' @rdname defunct

#' @export
compareMean <- function(...) { # formula, data=parent.frame(), ...) {
  .Defunct("diffmean")
}
