#' @rdname defunct
#' @export
compareProportion <- function(...) { # formula, data=NULL, ...) {
  .Defunct("diffprop")
}
