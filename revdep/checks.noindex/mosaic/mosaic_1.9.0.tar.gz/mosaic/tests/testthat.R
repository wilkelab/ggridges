library(testthat)
library(mosaic)

test_check("mosaic")
