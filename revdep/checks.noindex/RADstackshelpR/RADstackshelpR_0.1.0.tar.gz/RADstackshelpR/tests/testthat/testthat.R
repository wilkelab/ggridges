#install.packages("testthat")
library(testthat)
test_check("RADstackshelpR")
