.onload <- function(libname, pkgname){
  # utils::globalVariables("na.omit")
  # utils::globalVariables(".")
  # utils::globalVariables("tissueSiteDetailGTExv8")
  # utils::globalVariables("tissueSiteDetailGTExv7")
  #
  # invisible()

}
