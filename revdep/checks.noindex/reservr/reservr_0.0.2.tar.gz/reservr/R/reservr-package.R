## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib reservr, .registration = TRUE
## usethis namespace: end
NULL
