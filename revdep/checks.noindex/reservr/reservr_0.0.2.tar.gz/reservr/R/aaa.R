# Manual collate order for core classes and methods

#' @include interval.R
#' @include zzz.R
#' @include distribution_class.R
#' @include fit_util.R
NULL
