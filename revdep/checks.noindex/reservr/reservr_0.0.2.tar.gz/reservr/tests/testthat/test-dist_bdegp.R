test_that("test dist_bdegp", {
  expect_silent(dist_bdegp(1L, 2L, 365, 90))
})
