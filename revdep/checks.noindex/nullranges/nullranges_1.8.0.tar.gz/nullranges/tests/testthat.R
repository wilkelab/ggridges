library(testthat)
library(nullranges)

test_check("nullranges")
