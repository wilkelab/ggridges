library(testthat)
library(oxcAAR)

test_check("oxcAAR")
