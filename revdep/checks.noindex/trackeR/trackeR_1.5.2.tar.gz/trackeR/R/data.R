#' Training session.
#'
#' @format A \code{\link{trackeRdata}} object containing one running training session.
"run"

#' Training sessions.
#'
#' @format A \code{\link{trackeRdata}} object containing 33 running training sessions.
"runs"

