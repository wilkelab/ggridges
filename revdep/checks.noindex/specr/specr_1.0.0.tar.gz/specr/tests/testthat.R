library(testthat)
library(specr)

test_check("specr")
