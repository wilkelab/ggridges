
#' @export

roulette <- function(){
  

  cat("roulette() has been removed\n")
  cat("the roulette method is now available within elicit()\n")
 
}
