library(testthat)
library(SHELF)

test_check("SHELF")

