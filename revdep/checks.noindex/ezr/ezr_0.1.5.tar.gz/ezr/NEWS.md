# ezr 0.1.5
* Following the suggestion by Ms. Julia Haider, I wrapped the scatterplot
function's examples in "\donttest{}" as the execution time was greater 
than 5 seconds on linux

# ezr 0.1.4
* Wrapped the scatterplot function's examples in "dontrun" to avoid going over
5 seconds when testing in a linux system.

# ezr 0.1.3
* Removed unnecessary packages for importing and fixed other bugs

# ezr 0.1.2
* Added the main start_ezr function.

# ezr 0.1.1
* Added a `NEWS.md` file to track changes to the package.
