library(testthat)
library(benchdamic)

test_check("benchdamic")
