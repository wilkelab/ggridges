## usethis namespace: start
#' @importFrom methods setOldClass
#' @importFrom pillar pillar_shaft
#' @importFrom pillar type_sum
## usethis namespace: end
NULL

#' @keywords internal
#' @inherit summary.bench_mark examples
"_PACKAGE"
