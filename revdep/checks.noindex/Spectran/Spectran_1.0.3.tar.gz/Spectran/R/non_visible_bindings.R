Bestrahlungsstaerke<-
Wellenlaenge<-
Wert <- 
Abbr<-
Names<-
E<-
Type<-
rel_Sens<-
Peak<-
Testfarbe<-
y<-
x<-
.<-
Groesse<-
Einheit<-
equ<-
led<-
E<-
Adjec<-
Formelzeichen<-
Spectrum<-
Name<-
Beschreibung<-
.env<-
Identifier<-
Button_Name<-
Dateinamen<-
.data<-
lang_setting<-
label <- 
URL <- 
download <- 
Zeichen <- 
NULL