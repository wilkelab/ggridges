#' @keywords internal
#' @aliases Spectran-package
"_PACKAGE"

## usethis namespace: start
#' @importFrom magrittr %>%
## usethis namespace: end
NULL
