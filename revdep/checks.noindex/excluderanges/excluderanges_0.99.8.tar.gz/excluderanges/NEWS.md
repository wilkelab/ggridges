# excluderanges 0.99.8 (2022-11-08)
- Update README and the vignette to work with BioC 3.16

# excluderanges 0.99.7 (2022-09-30)
- Update and add new objects, including T2T and mm39 excluderanges sets, totaling 82
- Covering six organisms, various genome assemblies, includes NUMTs
- Use BEDbase for storage/overview of excluderanges

# excluderanges 0.99.5 (2021-10-09)
- Use AHub data in vignette and README

# excluderanges 0.99.4 (2021-10-07)
- Move CSV files to inst/extdata
- Update RDataPath in metadata

# excluderanges 0.99.2 (2021-10-01)
- Add code how to save to BED file

# excluderanges 0.99.1 (2021-08-31)
- Add tables to source files

# excluderanges 0.99.0 (2021-08-22)
- Initial commit
