library(testthat)
library(trialr)

test_check("trialr")
