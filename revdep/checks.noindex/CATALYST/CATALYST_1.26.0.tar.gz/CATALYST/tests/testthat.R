library(testthat)
library(CATALYST)

test_check("CATALYST")
