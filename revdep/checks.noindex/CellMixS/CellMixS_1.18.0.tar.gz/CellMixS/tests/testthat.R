library(testthat)
library(CellMixS)

test_check("CellMixS")
