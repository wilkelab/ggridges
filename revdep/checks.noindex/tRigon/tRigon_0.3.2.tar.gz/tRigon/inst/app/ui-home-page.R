home_page <- fluidRow(
  column(
    width = 12,
    includeMarkdown("homepage.Rmd")
  )
)
