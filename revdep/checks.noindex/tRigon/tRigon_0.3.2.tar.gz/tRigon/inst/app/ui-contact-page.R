contact_page <- fluidRow(
  column(
    width = 12,
    includeMarkdown("contact.Rmd")
  )
)
