## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
#  install.packages('tRigon')

## ----eval = FALSE-------------------------------------------------------------
#  library(tRigon)
#  tRigon::run_tRigon()

