# tRigon 0.3.2

* Initial CRAN submission.
