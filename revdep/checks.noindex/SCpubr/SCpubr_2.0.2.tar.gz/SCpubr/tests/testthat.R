# nolint start
library(testthat)
library(SCpubr)
# nolint end
test_check("SCpubr")
