#' Map of King County 
#' 
#' Shapefiles are King County in the Washington States.
#' 
"KingCounty"