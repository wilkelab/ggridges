require("spqn") || stop("unable to load the spqn package")
require("spqnData") || stop("unable to load the spqnData package")
require("SummarizedExperiment") || stop("unable to load the SummarizedExperiment package")
BiocGenerics:::testPackage("spqn")
