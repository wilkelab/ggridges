# Define global variables
utils::globalVariables(c("bin1", "mat.pr", "ci.min", "ci.max", "bin", "conf.high", "conf.low", "estimate", "mod", "term", "weight.high", "weight.low", "."))


