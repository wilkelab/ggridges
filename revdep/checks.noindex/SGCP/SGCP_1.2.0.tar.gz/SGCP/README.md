# SGCP : A semi-supervised pipeline for gene clustering using self-training approach in gene co-expression networks

SGC is a general pipline for gene co-expression network constructions and analysis. To install visit visit
[here](https://www.bioconductor.org/packages/release/bioc/html/SGC.html).
