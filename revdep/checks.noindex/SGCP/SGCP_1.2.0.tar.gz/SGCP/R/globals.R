globalVariables(c("GOtype", "Method", "Pvalue", "Var1", "Var2",
                "annotation_db", "clusterLabel", "clusterNum",
                "conductVal", "firstOrder", "index", "kfirst",
                "ksecond", "lb", "logPvalue", "remains",
                "secondOrder", "silIndex", "value", "clusterLabels"))
