## CiteFuse 0.99.7
* Improved Vignettes
* Add examples
* Fix for BiocCheck
* Remove Rcpp implementation
