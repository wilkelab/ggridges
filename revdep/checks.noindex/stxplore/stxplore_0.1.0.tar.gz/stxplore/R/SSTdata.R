#' The data from of the Sea Surface Temperature (SST) dataset. A subset of the original dataset is used.
#'
#' The original dataset is included in the STRbook R package.
#'
#' @format A dataframe with 500 rows and 396 columns.
#'
#'
"SSTdatashort"
