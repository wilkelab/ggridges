library(testthat)
library(Bchron)

test_check("Bchron")
