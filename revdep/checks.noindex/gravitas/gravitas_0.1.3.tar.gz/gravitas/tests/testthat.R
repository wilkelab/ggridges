library(testthat)
library(gravitas)

test_check("gravitas")
