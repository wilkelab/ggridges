library(testthat)
library(spotifyr)

test_check("spotifyr")
