library(testthat)
library(flowStats)

test_check("flowStats")
