library(testthat)
library(phyr)

test_check("phyr")
