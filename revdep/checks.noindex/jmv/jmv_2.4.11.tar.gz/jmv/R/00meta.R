
#' bugs
#'
#' @name bugs
#' @docType data
#' @author Ryan, Wilde & Crist (2013)
#'
#' @references
#' \url{https://faculty.kutztown.edu/rryan/RESEARCH/PUBS/Ryan,\%20Wilde,\%20\%26\%20Crist\%202013\%20Web\%20exp\%20vs\%20lab.pdf}
NULL

#' Tooth Growth
#'
#' @name ToothGrowth
#' @docType data
#' @keywords data
NULL

#' Big 5
#'
#' @name Big5
#' @docType data
#' @keywords data
NULL

#' iris
#'
#' @name iris
#' @docType data
#' @keywords data
NULL
