SINGULAR_WARNING <- "Linear model contains aliased coefficients (singular fit)"
