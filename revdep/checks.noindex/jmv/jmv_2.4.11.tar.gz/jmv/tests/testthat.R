library(testthat)
library(jmv)

test_check("jmv")
