library(testthat)
library(dispositionEffect)

test_check("dispositionEffect")
