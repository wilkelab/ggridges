# dispositionEffect 1.0.1

* Minor bug fix.


# dispositionEffect 1.0.0

* First release.
