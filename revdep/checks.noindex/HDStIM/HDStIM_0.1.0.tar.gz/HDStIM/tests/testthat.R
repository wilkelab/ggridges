library(testthat)
library(HDStIM)

test_check("HDStIM")
