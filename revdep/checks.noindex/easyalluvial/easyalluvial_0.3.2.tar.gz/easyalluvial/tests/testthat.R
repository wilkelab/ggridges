library(testthat)
library(easyalluvial)

test_check("easyalluvial")
