library(testthat)
library(GenomeAdmixR) # nolint

test_check("GenomeAdmixR")
