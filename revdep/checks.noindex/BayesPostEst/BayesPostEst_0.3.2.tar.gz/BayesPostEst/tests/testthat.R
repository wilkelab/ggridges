library(testthat)
library(BayesPostEst)

test_check("BayesPostEst")